// --------------------------------------------------------------------------------------
// Assignment 1
// Written by: Mohammad Ali Zahir 40077619
// For COMP 248 Section EC � Summer 2019
// Comments: Make a program which allows me print a basic message about my first program
// --------------------------------------------------------------------------------------

public class A1Q1 {
	public static void main(String args[]){

		System.out.println("Welcome to my First Java program!"+"\n"       //The \n means next line in the program 
				+"The statement System.out.println(\"Hello\"); will display"+"\n"
				+"Hello then move the cursor to the next line while the statement"+"\n"
				+ "System.out.print(\"Hello\"); will display"+"\n"
				+"Hello and the cursor will stay on the same line."+"\n"+"\n"
				+"All done!");    //Ending message here 
	}
}